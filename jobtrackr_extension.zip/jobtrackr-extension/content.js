// ---------- XPath helpers ----------
function getByXPath(xpath) {
  try {
    return document.evaluate(
      xpath,
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    ).singleNodeValue;
  } catch {
    return null;
  }
}

function getTextByXPath(xpath) {
  const el = getByXPath(xpath);
  if (!el) return "";
  return el.innerText?.trim() || "";
}

function getAttrByXPath(xpath, attr) {
  const el = getByXPath(xpath);
  if (!el) return "";
  return el.getAttribute(attr) || "";
}

// ---------- YOUR XPATHS ----------
const XPATHS = {
  role: "//button[contains(@aria-label,'More options')]//parent::div//following-sibling::div[1]//p",
  company: "//figure[contains(@aria-label,'Company')]//parent::div//p//a",
  logo: "//figure[contains(@aria-label,'Company')]//img",
};

// ---------- Scraper ----------
function scrapeJob() {
  const role = getTextByXPath(XPATHS.role);
  const company = getTextByXPath(XPATHS.company);
  const logo = getAttrByXPath(XPATHS.logo, "src");

  return {
    title: role,
    company,
    logo,
    url: window.location.href,
  };
}

// ---------- Wait for LinkedIn SPA ----------
function waitForJobData(retries = 30, delay = 400) {
  return new Promise((resolve) => {
    const interval = setInterval(() => {
      const job = scrapeJob();
      console.log("XPath scrape attempt:", job);

      if (job.title && job.company) {
        clearInterval(interval);
        resolve(job);
      }

      retries--;
      if (retries <= 0) {
        clearInterval(interval);
        resolve(null);
      }
    }, delay);
  });
}

// ---------- Message handler ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_JOB") {
    waitForJobData().then((job) => {
      sendResponse(job);
    });
    return true; // keep async channel open
  }
});
