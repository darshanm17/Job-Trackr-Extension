

document.addEventListener("DOMContentLoaded", () => {
  const SUPABASE_URL = "https://xqrqzssjrzilivhurwhi.supabase.co";
  const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhxcnF6c3NqcnppbGl2aHVyd2hpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY4OTc5MjEsImV4cCI6MjA4MjQ3MzkyMX0.A_TwfSlzSAXGue38YaFYpD39ugktaeTVXlX1zl-UMg4";

  const authDiv = document.getElementById("auth");
  const loggedDiv = document.getElementById("logged");
  const info = document.getElementById("info");

  const loginBtn = document.getElementById("login");
  const saveBtn = document.getElementById("save");
  const logoutBtn = document.getElementById("logout");
  const closeBtn = document.getElementById("closeBtn");

  // Close popup
  closeBtn.addEventListener("click", () => window.close());

  // Restore session
  chrome.storage.local.get(["session"], ({ session }) => {
    if (session?.access_token) {
      authDiv.style.display = "none";
      loggedDiv.style.display = "block";
    }
  });

  // Login
  loginBtn.addEventListener("click", async () => {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    info.innerText = "Logging in...";

    const res = await fetch(
      `${SUPABASE_URL}/auth/v1/token?grant_type=password`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ email, password }),
      }
    );

    const data = await res.json();

    if (!data.access_token) {
      info.innerText = "Login failed";
      return;
    }

    chrome.storage.local.set({ session: data });
    authDiv.style.display = "none";
    loggedDiv.style.display = "block";
    info.innerText = "Logged in";
  });

  // Save job
  saveBtn.addEventListener("click", () => {
    info.innerText = "Detecting job...";

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(
        tabs[0].id,
        { type: "GET_JOB" },
        async (job) => {
          if (!job || !job.title || !job.company) {
            info.innerText = "No job detected";
            return;
          }

          info.innerHTML = `
            <strong>${job.title}</strong><br/>
            ${job.company}<br/>
            ${job.logo ? `<img src="${job.logo}" />` : ""}
          `;

          chrome.storage.local.get(["session"], async ({ session }) => {
            if (!session?.access_token) {
              info.innerHTML += `<div class="error">Not logged in</div>`;
              return;
            }

            const cleanUrl = (() => {
              try {
                const u = new URL(job.url);
                return `${u.origin}${u.pathname}`;
              } catch {
                return job.url;
              }
            })();

            const encodedUrl = encodeURIComponent(cleanUrl);

            // Duplicate check
            const checkRes = await fetch(
              `${SUPABASE_URL}/rest/v1/applications?user_id=eq.${session.user.id}&url=eq.${encodedUrl}`,
              {
                headers: {
                  apikey: SUPABASE_ANON_KEY,
                  Authorization: `Bearer ${session.access_token}`,
                },
              }
            );

            const existing = await checkRes.json();
            if (existing.length > 0) {
              info.innerHTML += `<div class="error">Already saved</div>`;
              return;
            }

            // Insert
            const insertRes = await fetch(
              `${SUPABASE_URL}/rest/v1/applications`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  apikey: SUPABASE_ANON_KEY,
                  Authorization: `Bearer ${session.access_token}`,
                },
                body: JSON.stringify({
                  user_id: session.user.id,
                  company: job.company,
                  role: job.title,
                  logo: job.logo || null,
                  url: cleanUrl,
                  source: "LinkedIn",
                  applied_date: new Date().toISOString().split("T")[0],
                }),
              }
            );

            if (!insertRes.ok) {
              info.innerHTML += `<div class="error">Failed to save</div>`;
              return;
            }

            info.innerHTML += `<div class="success">Saved successfully</div>`;
          });
        }
      );
    });
  });

  // Logout
  logoutBtn.addEventListener("click", () => {
    chrome.storage.local.remove("session", () => {
      authDiv.style.display = "block";
      loggedDiv.style.display = "none";
      info.innerText = "Logged out";
    });
  });
});
